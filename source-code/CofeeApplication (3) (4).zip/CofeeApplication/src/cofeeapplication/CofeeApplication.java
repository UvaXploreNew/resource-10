/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofeeapplication;

/**
 *
 * @author Dilki
 */
public class CofeeApplication {

    public static void main(String[] args) {
        Coffee myOrder = new BasicCoffee();                  
        myOrder = new MilkDecorator(myOrder);               
        myOrder = new SugarDecorator(myOrder);              
        myOrder = new CreamDecorator(myOrder);             

        System.out.println("Order: " + myOrder.getDescription());
        System.out.println("Total Cost: $" + myOrder.getCost());
    }
    
}
